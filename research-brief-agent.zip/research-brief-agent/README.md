# research-brief-agent

Agentic skill that generates **academic Research Briefs** with traceable evidence: it searches PubMed, OpenAlex and Semantic Scholar, reranks with a coverage loop (max 3 iterations), writes the brief with APA 7 in-text citations and a **full References section at the end**, and verifies every DOI against Crossref.

## Requirements

- Python 3.8+ (standard library only; the scripts install nothing).
- Optional: `PUBMED_API_KEY` (higher PubMed rate limit) and `CROSSREF_EMAIL` (Crossref DOI verification).

## Usage

Invoke the agent with a natural-language question, e.g.:

> "Research the evidence on CBT for adolescent depression"

The agent optimizes the query, searches, reranks, asks you which sources to include, generates `research/brief-<topic>.md` and verifies the DOIs.

## Structure

```
research-brief-agent/
├── SKILL.md                        # skill instructions
├── README.md
├── scripts/
│   ├── search.py                   # multi-source search (PubMed/OpenAlex/Semantic Scholar)
│   ├── verify_dois.py              # DOI verification against Crossref
│   └── make_logo.py                # regenerates assets/logo.png
├── references/
│   ├── brief-format.md             # output format spec (references at the end)
│   └── original-prompts.md         # equivalent prompts from the original plugin, for external-LLM mode
└── assets/
    ├── brief-template.md           # brief template
    ├── logo.svg
    └── logo.png                    # 512x512, for the marketplace card
```

## Marketplace listing copy (Agensi)

*"Generates academic research briefs with traceable evidence from PubMed, OpenAlex and Semantic Scholar. Agentic rerank loop, APA 7 in-text citations, full References section at the end, DOI verification via Crossref. Saves hours of literature review per topic."*
