# research-brief-agent

Agentic skill that generates **academic Research Briefs** with traceable evidence: it searches PubMed, OpenAlex and Semantic Scholar (multilingual queries), reranks with a coverage loop (max 3 iterations), writes the brief with APA 7 in-text citations and a **full References section at the end**, verifies every DOI against Crossref, and **audits the output before delivery** (mechanical `scripts/audit.py` + semantic grounding pass by the agent).

## Requirements

- Python 3.8+ on `PATH` (standard library only; the scripts install nothing).
- Agent shell access (to run the scripts) and write access to a `research/` folder in the workspace.
- No API keys needed. Optional env vars for higher rate limits: `PUBMED_API_KEY`, `S2_API_KEY`, `CROSSREF_EMAIL`.
- Network access only to the declared APIs (see `external_urls` in SKILL.md): PubMed eutils, OpenAlex, Semantic Scholar, Crossref.

## Usage

Invoke the agent with a natural-language question, e.g.:

> "Research the evidence on CBT for adolescent depression"

The agent optimizes the query (English + your language), searches, reranks, asks you which sources to include, generates and audits `research/brief-<topic>.md`, verifies the DOIs, and writes `research/search-log.md`. A real complete example output ships in `assets/example-brief.md`.

## Structure

```
research-brief-agent/
├── SKILL.md                        # skill instructions (+ external_urls frontmatter)
├── README.md
├── scripts/
│   ├── search.py                   # multi-source search, PubMed abstracts via efetch, retries+backoff
│   ├── verify_dois.py              # DOI verification against Crossref
│   ├── audit.py                    # mechanical audit of the brief (structure + citations)
│   └── make_logo.py                # regenerates assets/logo.png (no dependencies)
├── references/
│   ├── brief-format.md             # output format spec (references at the end, any language)
│   └── original-prompts.md         # equivalent prompts from the original plugin, for external-LLM mode
└── assets/
    ├── brief-template.md           # brief template
    ├── example-brief.md            # real example of a complete generated brief
    └── logo.svg                    # logo (text). logo.png is generated via make_logo.py and used
                                    # only as the marketplace card image — keep it OUT of the uploaded zip
```

## Marketplace listing copy (Agensi)

*"Generates academic research briefs with traceable evidence from PubMed, OpenAlex and Semantic Scholar. Multilingual agentic rerank loop, APA 7 in-text citations, full References section at the end, Crossref DOI verification, and a built-in auditor that checks structure and citations before delivery. Real example output included. Zero configuration — no API keys needed."*
