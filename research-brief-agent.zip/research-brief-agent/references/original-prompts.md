# Original prompts (external-LLM mode)

The skill is designed so the agent itself does the reasoning (no API key needed). If you prefer to delegate to an external LLM via API, these are the equivalent prompts from the original Obsidian plugin (`jaliriogbarrios19/Research_Paper`):

| Skill step | Original prompt in the repo |
|---|---|
| 1. Optimize query (5 variants + domain) | `src/search-service.ts:78` (`optimizeQuery`) |
| 3a. Rerank (score 0–1 + reason) | `src/search-service.ts:116` (`rerankResults`) |
| 3b. Coverage (≥3 sources ≥0.7; else gaps + refinedQuery) | `src/search-service.ts:153` (`evaluateCoverage`) |
| 5. Generate brief (structure + anti-hallucination) | `src/brief-service.ts:9` (`generateBrief`) — adapted: References at the end |
| DOI verification (Crossref) | `src/brief-service.ts:140` (`verifyDOIs`) → here `scripts/verify_dois.py` |
| Bahá'í domain (optional) | `src/bahai-brief.ts:135` (`generateBahaiBrief`) + canonical list `KNOWN_BAHAI_TEXTS` |

Key differences vs the plugin: OpenAlex abstracts are reconstructed from `abstract_inverted_index` (they arrived empty in the plugin), there are 3 sources (Semantic Scholar added), and the max number of sources is configurable (`--max`).
