# Research Brief format

Output language: the language the user writes in. Section headers go in that language (canonical EN + ES below; add others as needed).

## Mandatory structure (in this order)

```
## Research Brief: {concise title}

### Research Question / Pregunta de investigación
{the user's original question}

### Summary and findings per source / Resumen y hallazgos por fuente
{for EACH selected source:
  1. Summary: 2-3 sentences faithfully paraphrasing the source abstract IN the output language
     (if no abstract: "Abstract not available" / "Resumen no disponible").
  2. Findings: 2-4 bullets with the key findings; each bullet starts with an APA 7 in-text
     citation (Author, Year). Include population, method and effect sizes when available.}

### Convergences / Convergencias
{2-4 bullets where several sources agree. Citations like (Author, Year; Other, Year).}

### Divergences / Divergencias
{2-4 bullets where sources differ and why (population, method, period). APA 7 citations.}

### Implications / Implicaciones
{2-3 paragraphs of overall synthesis. APA 7 in-text citations.}

### References / Referencias
{ALWAYS LAST! One line per source, full APA 7, alphabetical by first author:
  Author, A. A., & Author, B. B. (Year). Article title. *Journal*, *vol*(issue), xx–yy. [DOI: 10.xxxx](https://doi.org/10.xxxx)
  DOI always as a clickable link. Source without DOI: no link.}
```

## Rules

- Only sources retrieved with `scripts/search.py` and selected by the user. **Never invent sources, DOIs, pages, or citations.**
- In the body only in-text citations (Author, Year). Full source details ONLY in the final References section.
- The summary paraphrases the abstract in the output language; do not copy the abstract verbatim.
- No extra sections: no Introduction, Methods, Discussion, or Conclusion.
- Clean markdown: no HTML entities, no LaTeX, no code fences.
- Optional first line: `> AI-assisted brief: all factual claims are traceable to the sources listed in References.`
- If a DOI was marked `*(DOI not verified)*` by `scripts/verify_dois.py`, fix it or remove that source before delivering.
