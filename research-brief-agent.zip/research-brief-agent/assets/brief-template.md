## Research Brief: {concise title in the output language}

> AI-assisted brief: all factual claims are traceable to the sources listed in References.

### Research Question
{the user's original question}

### Summary and findings per source
**Author, Year — Title.** Summary: {2-3 sentences paraphrasing the abstract in the output language}.
- (Author, Year) key finding 1…
- (Author, Year) key finding 2…

### Convergences
- (Author, Year; Other, Year) the sources agree that…

### Divergences
- (Author, Year) vs. (Other, Year): they differ on… (population/method/period)

### Implications
{2-3 paragraphs of synthesis with in-text citations (Author, Year)}

### References
Author, A. A. (Year). Title. *Journal*, *vol*(issue), pp. [DOI: 10.xxxx](https://doi.org/10.xxxx)
Author, B. B., & Author, C. C. (Year). Title. *Journal*, *vol*(issue), pp. [DOI: 10.yyyy](https://doi.org/10.yyyy)
