## Research Brief: Eating multiple carbohydrates in one meal and postprandial glucose/insulin — links to metabolic dysregulation

> AI-assisted brief: all factual claims are traceable to the sources listed in References.

### Research Question
What is the relationship between the habit of combining several carbohydrate foods in the same meal and blood glucose/insulin responses, and how does this relate to metabolic dysregulation?

### Summary and findings per source

**Sun et al. (2020) — PATTERN study.** This crossover study examined whether the *order* in which macronutrients of a test meal are eaten changes postprandial glucose, insulin and incretin responses. Prior evidence (mostly in prediabetes/type 2 diabetes) shows that the sequential order of food components significantly impacts postprandial glucose and insulin excursions, indicating that meal structure — not only meal content — modulates the metabolic response.
- (Sun et al., 2020) macronutrient ingestion sequence within a single meal alters postprandial glucose and insulin excursions.
- (Sun et al., 2020) the effect has been demonstrated mainly in prediabetes and type 2 diabetes populations; the study extends the question to healthy adults.

**Papakonstantinou et al. (2022) — narrative review.** This review covers diet, lifestyle and chrononutrition effects on postprandial glycemia and insulin resistance. It notes that people spend most of the day in the postprandial state, that eating most carbohydrates earlier in the day and keeping a consistent number and timing of meals matters, and that eating low-energy-density foods first (vegetables, salads, soups), then protein, then starchy foods, ameliorates glycemic and insulin responses.
- (Papakonstantinou et al., 2022) food sequence within a meal matters: vegetables/salad first, then protein, then starch, reduces postprandial glucose and insulin responses.
- (Papakonstantinou et al., 2022) consistent meal number and timing, and front-loading carbohydrates earlier in the day, support postprandial glycemia and insulin sensitivity.
- (Papakonstantinou et al., 2022) lifestyle intervention with 7–10% weight loss plus 150 min/week of moderate exercise is highly effective in preventing and treating type 2 diabetes.

**Pasmans et al. (2022) — narrative review.** This review summarizes nutritional strategies to attenuate postprandial hyperglycemia: reducing total carbohydrate intake, choosing lower-glycemic-index carbohydrates, adding or substituting sweeteners and fiber, and using food compounds that delay gastric emptying, inhibit carbohydrate digestion, or inhibit intestinal glucose absorption. It stresses that individual responses vary and a personalized approach is needed.
- (Pasmans et al., 2022) lowering postprandial hyperglycemia can be achieved by reducing total carbohydrate or switching to lower-GI carbohydrates.
- (Pasmans et al., 2022) fiber, sweeteners and compounds that slow gastric emptying/digestion or block intestinal glucose absorption also blunt the postprandial spike.
- (Pasmans et al., 2022) responses are highly individual, so the optimal strategy must be personalized; lifestyle intervention may lower hyperglycemia more effectively than drugs.

**Bergia et al. (2022) — MEDGI-Carb randomized controlled trial.** In 160 adults at risk for type 2 diabetes (≥2 metabolic syndrome traits, BMI ~31), a 12-week randomized comparison of low- vs high-GI Mediterranean-style diets assessed postprandial glucose and insulin responses to standardized test meals and daily glycemic variability by continuous glucose monitoring.
- (Bergia et al., 2022) postprandial insulin was significantly greater after high-GI than low-GI test meals at baseline (p = 0.004).
- (Bergia et al., 2022) after the 12-week intervention the insulin difference between high- and low-GI meals was no longer significant (p = 0.17), suggesting adaptation to the assigned eating pattern.
- (Bergia et al., 2022) low-GI eating patterns are a practical way to minimize postprandial glucose excursions in at-risk adults.

**Wolever et al. (2022) — four randomized crossover trials.** Across four trials (n = 160 healthy adults), test meals were matched for fat, protein and available carbohydrate but varied in the ratio of rapidly available glucose to slowly available glucose (RAG:SAG) of the starch. Blood glucose, serum insulin and hunger were measured for 3 h.
- (Wolever et al., 2022) each 50% reduction in the RAG:SAG ratio reduced the relative postprandial glucose response by about 4%.
- (Wolever et al., 2022) lower RAG:SAG cereals elicited significantly lower glucose iAUC0–2 and lower insulin responses than control cereals.
- (Wolever et al., 2022) because meals were matched for total available carbohydrate, the effect is attributable to carbohydrate *quality/speed of availability*, not quantity.

**Moravek et al. (2018) — acute randomized crossover trial.** In 48 healthy adults, replacing half of the available carbohydrate from white rice or instant potato with cooked lentils (50:50 combination) in a mixed meal was compared with rice or potato alone (50 g available carbohydrate per test meal); glucose, insulin, iAUC and Cmax were measured.
- (Moravek et al., 2018) replacing half the carbohydrate of a high-GI staple (rice or potato) with lentils lowered the postprandial blood glucose response and relative glycemic response versus the staple alone.
- (Moravek et al., 2018) the reduction occurred within a mixed meal, i.e., by *substituting part of the carbohydrate*, not by removing carbohydrate from the meal.

**Alshaalan et al. (2024) — randomized crossover trial with mechanistic arm.** In 15 healthy participants, hummus made from intact chickpea cells (ICC) vs ruptured cells (RCC), both providing 27 g starch, was compared; in vitro digestion, microstructure and rheology were also assessed.
- (Alshaalan et al., 2024) postprandial insulin and GIP were significantly lower after the intact-cell hummus meal (P < 0.02, P < 0.03).
- (Alshaalan et al., 2024) starch digestion was slower for the intact-cell meal, showing that food structure — not just nutrient content — controls the rate of carbohydrate digestion.
- (Alshaalan et al., 2024) slowing carbohydrate digestion produces low postprandial glucose and insulin responses, which are associated with reduced risk of type 2 diabetes.

**Mazidi et al. (2021) — PREDICT 1 study.** In 1002 healthy adults, postprandial (0–6 h) glucose, triglycerides, IL-6 and GlycA were measured after sequential mixed-nutrient meals, together with habitual diet, microbiome and visceral fat.
- (Mazidi et al., 2021) postprandial inflammatory responses were highly variable between individuals; 94% of participants showed an IL-6 increase (mean 6-h increase ~190%).
- (Mazidi et al., 2021) peak postprandial triglyceride and glucose concentrations were associated with the postprandial inflammatory response.
- (Mazidi et al., 2021) meal-induced acute inflammation links repeated postprandial metabolic excursions to chronic inflammation and associated diseases.

### Convergences
- (Wolever et al., 2022; Moravek et al., 2018; Bergia et al., 2022; Alshaalan et al., 2024) carbohydrate *quality* — GI, RAG:SAG ratio, food structure, or substitution with pulses — predicts the size of the postprandial glucose and insulin response even when total carbohydrate is held constant.
- (Sun et al., 2020; Papakonstantinou et al., 2022) the *composition and sequence* of a meal (what is eaten first, and alongside the carbohydrate) also modulate postprandial glucose and insulin.
- (Papakonstantinou et al., 2022; Pasmans et al., 2022; Mazidi et al., 2021) repeated exaggerated postprandial glucose/insulin excursions and meal-induced inflammation are associated with insulin resistance, type 2 diabetes risk and cardiometabolic disease.

### Divergences
- (Bergia et al., 2022) vs. (Wolever et al., 2022; Moravek et al., 2018): in MEDGI-Carb, the high- vs low-GI insulin difference was significant at baseline but not after 12 weeks of the intervention, whereas acute crossover trials show immediate effects — adaptation over time can blur short-term differences.
- (Sun et al., 2020) vs. (Moravek et al., 2018): meal-sequence effects are best documented in prediabetes/T2D; in healthy adults the acute effects of carbohydrate substitution/quality are clearer than sequence effects.
- (Mazidi et al., 2021; Pasmans et al., 2022) postprandial responses vary widely between individuals, so the same mixed-carbohydrate meal can produce very different glucose/insulin/inflammatory responses in different people.

### Implications
The habit of loading a single meal with several refined, high-GI carbohydrate foods tends to produce larger postprandial glucose and insulin spikes, because the total rapidly available glucose is high and, if eaten together without fiber/protein/vegetables first, digestion is faster. Over time, repeated spikes and the associated meal-induced inflammation are linked to insulin resistance and metabolic dysregulation (type 2 diabetes, metabolic syndrome). The evidence supports practical mitigation *within* the same meal: eat vegetables/protein first and starch last, replace part of the refined starch with pulses (lentils), choose lower-GI and more intact food structures, and keep meal timing consistent (Papakonstantinou et al., 2022; Pasmans et al., 2022; Moravek et al., 2018; Wolever et al., 2022; Alshaalan et al., 2024). Important caveat: most trials are acute crossover studies or short-term RCTs in healthy/at-risk adults that manipulate carbohydrate type, amount or sequence within meals; none directly tests the long-term effect of the specific habit "several different carbohydrate foods in the same meal" versus a single carbohydrate source, so long-term causal evidence for that exact habit is still limited (Mazidi et al., 2021; Sun et al., 2020).

### References
Alshaalan, R., Charalambides, M., Edwards, C., Ellis, P. R., Alrabeah, S. H., & Frost, G. (2024). Impact of chickpea hummus on postprandial blood glucose, insulin and gut hormones in healthy humans combined with mechanistic studies of food structure, rheology and digestion kinetics. *Food Research International*, *188*, 114517. [DOI: 10.1016/j.foodres.2024.114517](https://doi.org/10.1016/j.foodres.2024.114517)

Bergia, R. E., Giacco, R., Hjorth, T., Biskup, I., Zhu, W., & Costabile, G. (2022). Differential glycemic effects of low- versus high-glycemic index Mediterranean-style eating patterns in adults at risk for type 2 diabetes: The MEDGI-Carb randomized controlled trial. *Nutrients*, *14*(3), 706. [DOI: 10.3390/nu14030706](https://doi.org/10.3390/nu14030706)

Mazidi, M., Valdes, A. M., Ordovás, J. M., Hall, W. L., Pujol, J. C., & Wolf, J. (2021). Meal-induced inflammation: Postprandial insights from the Personalised REsponses to DIetary Composition Trial (PREDICT) study in 1000 participants. *The American Journal of Clinical Nutrition*, *114*(3), 1028–1038. [DOI: 10.1093/ajcn/nqab132](https://doi.org/10.1093/ajcn/nqab132)

Moravek, D., Duncan, A., VanderSluis, L., Turkstra, S. J., Rogers, E. J., Wilson, J. M., Hawke, A., & Ramdath, D. D. (2018). Carbohydrate replacement of rice or potato with lentils reduces the postprandial glycemic response in healthy adults in an acute, randomized, crossover trial. *The Journal of Nutrition*, *148*(4), 535–541. [DOI: 10.1093/jn/nxy018](https://doi.org/10.1093/jn/nxy018)

Papakonstantinou, E., Oikonomou, C., Nychas, G.-J. E., & Dimitriadis, G. (2022). Effects of diet, lifestyle, chrononutrition and alternative dietary interventions on postprandial glycemia and insulin resistance. *Nutrients*, *14*(4), 823. [DOI: 10.3390/nu14040823](https://doi.org/10.3390/nu14040823)

Pasmans, K., Meex, R. C. R., van Loon, L. J. C., & Blaak, E. E. (2022). Nutritional strategies to attenuate postprandial glycemic response. *Obesity Reviews*, *23*(9), e13486. [DOI: 10.1111/obr.13486](https://doi.org/10.1111/obr.13486)

Sun, L., Goh, H. J., Govindharajulu, P., Leow, M. K.-S., & Henry, C. J. (2020). Postprandial glucose, insulin and incretin responses differ by test meal macronutrient ingestion sequence (PATTERN study). *Clinical Nutrition*, *39*(3), 950–957. [DOI: 10.1016/j.clnu.2019.04.001](https://doi.org/10.1016/j.clnu.2019.04.001)

Wolever, T. M. S., Jenkins, A. L., Campbell, J. E., Ezatagha, A., Dhillon, S., & Johnson, J. L. (2022). Decreasing the RAG:SAG ratio of granola cereal predictably reduces postprandial glucose and insulin responses: A report of four randomised trials in healthy adults. *Journal of Nutritional Science*, *11*, e22. [DOI: 10.1017/jns.2022.22](https://doi.org/10.1017/jns.2022.22)
