#!/usr/bin/env python3
"""Searches academic works in PubMed, OpenAlex and Semantic Scholar.

Standard library only: installs nothing, writes nothing.
Optional credentials via environment variables: PUBMED_API_KEY, CROSSREF_EMAIL.
Output: JSON on stdout with {"results": [...], "errors": [...]}.
"""
import argparse
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request

PUBMED_BASE = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"
OPENALEX_BASE = "https://api.openalex.org/works"
S2_BASE = "https://api.semanticscholar.org/graph/v1/paper/search"
PUBMED_DOMAINS = {"psychology", "medicine", "nursing", "biology"}
UA = {"User-Agent": "research-brief-agent/1.0"}


def http_json(url, retries=1):
    err = None
    for _ in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=30) as res:
                return json.loads(res.read().decode("utf-8"))
        except Exception as exc:
            err = exc
            time.sleep(1.5)
    raise RuntimeError(f"{url} -> {err}")


def norm_doi(doi):
    if not doi:
        return ""
    return doi.replace("https://doi.org/", "").replace("http://doi.org/", "").lower()


def reconstruct_abstract(inverted):
    """Rebuilds the abstract from OpenAlex's abstract_inverted_index."""
    if not inverted:
        return ""
    size = max(p for positions in inverted.values() for p in positions) + 1
    words = [""] * size
    for word, positions in inverted.items():
        for p in positions:
            words[p] = word
    return " ".join(words)


def fetch_pubmed(query, api_key, year_min):
    params = {"db": "pubmed", "term": query, "retmode": "json", "retmax": "20"}
    if api_key:
        params["api_key"] = api_key
    data = http_json(f"{PUBMED_BASE}/esearch.fcgi?{urllib.parse.urlencode(params)}")
    ids = data.get("esearchresult", {}).get("idlist", [])
    works = []
    if not ids:
        return works
    sp = {"db": "pubmed", "id": ",".join(ids), "retmode": "json"}
    if api_key:
        sp["api_key"] = api_key
    summary = http_json(f"{PUBMED_BASE}/esummary.fcgi?{urllib.parse.urlencode(sp)}").get("result", {})
    for pid in ids:
        art = summary.get(pid)
        if not art:
            continue
        doi = next((a["value"] for a in art.get("articleids", []) if a.get("idtype") == "doi"), "")
        year = int((art.get("pubdate") or "0").split(" ")[0] or 0)
        if year_min and year and year < year_min:
            continue
        works.append({
            "doi": doi,
            "title": art.get("title", ""),
            "authors": [a.get("name", "") for a in art.get("authors", [])],
            "year": year,
            "journal": art.get("fulljournalname", ""),
            "abstract": "",
            "score": 0.9,
            "source": "pubmed",
            "url": f"https://doi.org/{doi}" if doi else f"https://pubmed.ncbi.nlm.nih.gov/{pid}/",
        })
    return works


def fetch_openalex(query, email, year_min):
    params = {"search": query, "per-page": "20", "mailto": email or "research-brief-agent"}
    if year_min:
        params["filter"] = f"from_publication_date:{year_min}-01-01"
    data = http_json(f"{OPENALEX_BASE}?{urllib.parse.urlencode(params)}")
    works = []
    for w in data.get("results", []):
        doi = norm_doi(w.get("doi") or "")
        year = w.get("publication_year") or 0
        if year_min and year and year < year_min:
            continue
        works.append({
            "doi": doi,
            "title": w.get("display_name") or w.get("title") or "",
            "authors": [a.get("author", {}).get("display_name", "") for a in w.get("authorships", [])],
            "year": year,
            "journal": (w.get("host_venue") or {}).get("display_name", ""),
            "abstract": reconstruct_abstract(w.get("abstract_inverted_index")),
            "score": float(w.get("relevance_score") or 0.5),
            "source": "openalex",
            "url": w.get("doi") or w.get("id", ""),
        })
    return works


def fetch_semantic_scholar(query, year_min):
    params = {
        "query": query,
        "limit": "20",
        "fields": "title,year,authors,abstract,externalIds,venue,url,citationCount",
    }
    if year_min:
        params["year"] = f"{year_min}-"
    data = http_json(f"{S2_BASE}?{urllib.parse.urlencode(params)}")
    works = []
    for p in data.get("data", []):
        ext = p.get("externalIds") or {}
        doi = norm_doi(ext.get("DOI", ""))
        year = p.get("year") or 0
        if year_min and year and year < year_min:
            continue
        cites = p.get("citationCount") or 0
        works.append({
            "doi": doi,
            "title": p.get("title", ""),
            "authors": [a.get("name", "") for a in p.get("authors", [])],
            "year": year,
            "journal": p.get("venue", ""),
            "abstract": p.get("abstract") or "",
            "score": round(min(1.0, 0.5 + cites / 200.0), 3),
            "source": "semantic-scholar",
            "url": p.get("url") or (f"https://doi.org/{doi}" if doi else ""),
        })
    return works


def main():
    ap = argparse.ArgumentParser(description="Multi-source academic search (stdlib only)")
    ap.add_argument("--query", required=True, help="search query (English keywords)")
    ap.add_argument("--domain", default="general", help="academic domain; PubMed only if biomedical")
    ap.add_argument("--years", type=int, default=10, help="years back; 0 = all time")
    ap.add_argument("--max", type=int, default=10, help="max results after dedup (default 10)")
    ap.add_argument("--sources", default="pubmed,openalex,semantic-scholar")
    args = ap.parse_args()

    year_min = (int(time.strftime("%Y")) - args.years) if args.years > 0 else 0
    api_key = os.environ.get("PUBMED_API_KEY", "")
    email = os.environ.get("CROSSREF_EMAIL", "")

    wanted = {s.strip() for s in args.sources.split(",") if s.strip()}
    fetchers = []
    if "pubmed" in wanted and args.domain in PUBMED_DOMAINS:
        fetchers.append(lambda: fetch_pubmed(args.query, api_key, year_min))
    if "openalex" in wanted:
        fetchers.append(lambda: fetch_openalex(args.query, email, year_min))
    if "semantic-scholar" in wanted:
        fetchers.append(lambda: fetch_semantic_scholar(args.query, year_min))

    merged, seen, errors = [], set(), []
    for i, fn in enumerate(fetchers):
        try:
            for w in fn():
                key = norm_doi(w.get("doi")) or (w.get("title") or "").lower()
                if key and key not in seen:
                    seen.add(key)
                    merged.append(w)
        except Exception as exc:
            errors.append(f"source #{i + 1}: {exc}")

    merged.sort(key=lambda w: w.get("score", 0), reverse=True)
    print(json.dumps({"results": merged[: args.max], "errors": errors}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
