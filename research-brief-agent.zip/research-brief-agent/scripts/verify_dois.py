#!/usr/bin/env python3
"""Verifies the DOIs in a markdown file against the Crossref API.

DOIs that return 404 are marked in the file with *(DOI not verified)*.
Standard library only. Optional email (better rate limit): CROSSREF_EMAIL.
Usage: verify_dois.py <file.md>
"""
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

CROSSREF = "https://api.crossref.org/works/"
DOI_RE = re.compile(r"(?:https?://doi\.org/|\[DOI:\s*)(10\.\d{4,9}/[^\s\]\)]+)", re.IGNORECASE)
UA = {"User-Agent": "research-brief-agent/1.0"}


def doi_ok(doi, email):
    url = CROSSREF + urllib.parse.quote(doi, safe="") + "?mailto=" + urllib.parse.quote(email or "research-brief-agent")
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=20) as res:
            return 200 <= res.status < 300
    except urllib.error.HTTPError as exc:
        return exc.code != 404
    except Exception:
        return True  # network failure: do not flag


def main(path):
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    email = os.environ.get("CROSSREF_EMAIL", "")
    dois, lower = [], set()
    for m in DOI_RE.finditer(text):
        doi = m.group(1).rstrip(".,;)")
        if doi.lower() not in lower:
            lower.add(doi.lower())
            dois.append(doi)
    invalid = []
    for doi in dois:
        if not doi_ok(doi, email):
            invalid.append(doi)
            text = text.replace(
                f"https://doi.org/{doi}", f"https://doi.org/{doi} *(DOI not verified)*"
            )
            text = text.replace(
                f"[DOI: {doi}]", f"[DOI: {doi}] *(DOI not verified)*"
            )
        time.sleep(0.3)
    if invalid:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
    print(json.dumps(
        {"file": path, "dois_found": len(dois), "unverified": invalid},
        ensure_ascii=False, indent=2,
    ))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: verify_dois.py <file.md>")
    main(sys.argv[1])
