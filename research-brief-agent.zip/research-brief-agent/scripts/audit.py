#!/usr/bin/env python3
"""Mechanical audit of a generated brief (the "auditor" pass, part 1).

Checks structure and citation mechanics. The agent still performs the
semantic audit (grounding of every claim) described in SKILL.md step 6.

Usage: audit.py <file.md>   -> exit 0 = PASS, 1 = FAIL (one line per check)
Standard library only.
"""
import re
import sys

SECTION_PATTERNS = [
    ("title", r"^## .*(Research Brief|Brief de investigaci)"),
    ("question", r"^### .*(Research Question|Pregunta de investigaci)"),
    ("summary_findings", r"^### .*(Summary and findings|Resumen y hallazgos)"),
    ("convergences", r"^### .*(Convergences|Convergencias)"),
    ("divergences", r"^### .*(Divergences|Divergencias)"),
    ("implications", r"^### .*(Implications|Implicaciones)"),
    ("references", r"^### .*(References|Referencias)\s*$"),
]


def main(path):
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    fails = []

    def check(name, ok, detail=""):
        print(("PASS" if ok else "FAIL"), "-", name, detail)
        if not ok:
            fails.append(name)

    pos = -1
    order_ok = True
    for _name, pat in SECTION_PATTERNS:
        m = re.search(pat, text, re.M)
        if not m or m.start() <= pos:
            order_ok = False
            break
        pos = m.start()
    check("all sections present and in order", order_ok)

    headers = re.findall(r"^### .+$", text, re.M)
    check("References is the last section",
          bool(headers) and bool(re.search(r"(References|Referencias)\s*$", headers[-1])))

    placeholders = re.findall(r"\{[A-Za-z][^{}]*\}", text)
    check("no unfilled placeholders", not placeholders, str(placeholders[:3]))

    check("no 'DOI not verified' markers left",
          "DOI not verified" not in text and "DOI no verificado" not in text)

    mref = re.search(r"^### .*(References|Referencias)\s*$", text, re.M)
    body, refs = (text, "") if not mref else (text[: mref.start()], text[mref.start():])

    doi_entries = re.findall(r"\[DOI:\s*(10\.\d{4,9}/[^\]\s]+)\]\(https://doi\.org/([^\)]+)\)", refs)
    check("every DOI in References is a clickable link",
          bool(doi_entries) and all(a.lower() == b.lower() for a, b in doi_entries))
    dois = [a.lower() for a, _ in doi_entries]
    check("reference DOIs are unique", len(dois) == len(set(dois)))

    ref_lines = [l for l in refs.splitlines() if l.strip() and not l.lstrip().startswith("#")]
    check("one DOI link per reference entry (or none)",
          all(("[DOI:" in l) == ("https://doi.org/" in l) for l in ref_lines))

    cited = set(re.findall(r"([A-Z][A-Za-z'’\-]+)(?: et al\.)?,\s*(\d{4})", body))
    ref_keys = set()
    for l in ref_lines:
        m = re.match(r"\s*([A-Z][A-Za-z'’\-]+),.*?\((\d{4})\)", l)
        if m:
            ref_keys.add((m.group(1), m.group(2)))
    missing = [c for c in cited if c not in ref_keys]
    check("every in-text citation has a References entry", not missing, str(missing[:3]))
    uncited = [r for r in ref_keys if r not in cited]
    check("every References entry is cited in the text", not uncited, str(uncited[:3]))

    print("RESULT:", "PASS" if not fails else f"FAIL ({', '.join(fails)})")
    sys.exit(0 if not fails else 1)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit("usage: audit.py <file.md>")
    main(sys.argv[1])
