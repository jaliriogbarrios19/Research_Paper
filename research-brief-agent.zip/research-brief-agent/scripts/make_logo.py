#!/usr/bin/env python3
"""Regenerates assets/logo.png (512x512 RGBA) with no dependencies: only zlib + struct.

Design: rounded square with an indigo->violet gradient, a white magnifying glass and a cyan dot.
"""
import math
import os
import struct
import zlib

S = 512
SS = 2
TOP = (79, 70, 229)
BOTTOM = (124, 58, 237)
WHITE = (255, 255, 255)
ACCENT = (34, 211, 238)


def lerp(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))


def rounded_rect_d(x, y, cx, cy, half, r):
    qx = abs(x - cx) - (half - r)
    qy = abs(y - cy) - (half - r)
    return math.hypot(max(qx, 0.0), max(qy, 0.0)) + min(max(qx, qy), 0.0) - r


def circle_d(x, y, cx, cy, r):
    return math.hypot(x - cx, y - cy) - r


def segment_d(x, y, x1, y1, x2, y2, w):
    dx, dy = x2 - x1, y2 - y1
    t = max(0.0, min(1.0, ((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy)))
    return math.hypot(x - (x1 + t * dx), y - (y1 + t * dy)) - w


def render():
    w = h = S * SS
    cx = cy = S / 2.0
    rows = []
    for py in range(h):
        row = bytearray([0])
        t = py / h
        bg = lerp(TOP, BOTTOM, t)
        for px in range(w):
            x, y = px / SS, py / SS
            d = rounded_rect_d(x, y, cx, cy, S / 2 - 8, 110)
            if d >= 0:
                row += bytes((0, 0, 0, 0))
                continue
            col = bg
            lens = circle_d(x, y, 205, 205, 105 - 24)
            if lens < 0:
                col = lerp(col, WHITE, 0.08)
            ring = abs(circle_d(x, y, 205, 205, 105)) - 24
            handle = segment_d(x, y, 279, 279, 395, 395, 17)
            if min(ring, handle) < 0:
                col = WHITE
            if circle_d(x, y, 392, 118, 20) < 0:
                col = ACCENT
            row += bytes((int(col[0]), int(col[1]), int(col[2]), 255))
        rows.append(bytes(row))
    # box downsample SS x SS -> S x S
    out = bytearray()
    for py in range(S):
        row = bytearray([0])
        for px in range(S):
            acc = [0, 0, 0, 0]
            for dy in range(SS):
                r = rows[py * SS + dy]
                for dx in range(SS):
                    o = 1 + (px * SS + dx) * 4
                    for c in range(4):
                        acc[c] += r[o + c]
            n = SS * SS
            row += bytes(v // n for v in acc)
        out += row
    return bytes(out)


def write_png(path, raw):
    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", S, S, 8, 6, 0, 0, 0)
    png = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", ihdr)
        + chunk(b"IDAT", zlib.compress(raw, 9))
        + chunk(b"IEND", b"")
    )
    with open(path, "wb") as fh:
        fh.write(png)


if __name__ == "__main__":
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dest = os.path.join(here, "assets", "logo.png")
    write_png(dest, render())
    print(dest)
