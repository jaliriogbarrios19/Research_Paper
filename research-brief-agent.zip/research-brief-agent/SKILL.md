---
name: research-brief-agent
description: 'Generates academic research briefs with traceable evidence from real sources (PubMed, OpenAlex, Semantic Scholar), APA 7 in-text citations and a full References section at the end, DOI verification via Crossref, and a built-in auditor pass that checks structure and citations before delivery. Use when the user asks to research a topic, find academic evidence, or write a research brief / literature review ("investigate...", "what does the literature say about...", "search for evidence on..."; Spanish triggers: "investiga...", "busca evidencia sobre...", "estado del arte de...").'
argument-hint: "natural-language research question (optional: domain, year range, output language, max number of sources)"
external_urls:
  - https://eutils.ncbi.nlm.nih.gov
  - https://api.openalex.org
  - https://api.semanticscholar.org
  - https://api.crossref.org
---

# Research Brief Agent

You generate an academic **Research Brief**: a synthesis with APA 7 in-text citations and a **full References section at the end**, using only real sources retrieved from academic databases — and you **audit your own output before delivering it**. Never invent sources, DOIs, pages, or citations.

## Inputs

1. Take the **research question** from the user in natural language.
2. Optional parameters (infer if not given): academic domain, year range (default: last 10 years), output language (= the user's language), max number of sources (default: 10).

## Procedure

1. **Optimize the query (multilingual)**: produce 5 English keyword variants (primary, synonyms, MeSH-style, broader, narrower) **plus up to 3 variants in the user's own language**, and infer the domain. If the chosen domain is "general" and the inferred one is not, use the inferred one.
2. **Search**: run `scripts/search.py --query "<primary English variant>" ...` and, if the user's language is not English, also with the primary user-language variant; merge results (the script already dedups by DOI). Run with `--domain <domain> --years <n> --max <n>`. If one source fails (e.g. rate limit), continue with the rest and note it.
3. **Rerank (agentic loop, max 3 iterations)**:
   - a) Score each result 0.0–1.0 for relevance to the question (topic, population, methodology, recency) and note a short reason.
   - b) **Coverage**: if ≥3 sources score ≥0.7, coverage is sufficient → go to step 4. Otherwise identify what is missing, propose a refined query and search again with it (or with the next variant). At most 3 iterations.
   - c) Deduplicate by DOI (or lowercase title) across iterations and sort by score.
4. **User checkpoint**: show the ranked list (title, year, score, reason) and ask which sources to include and whether there are extra instructions. By default, all are preselected.
5. **Generate the brief** following exactly `references/brief-format.md` and the template `assets/brief-template.md`. Key structural rules: **full References ALWAYS go last**, in their own section; in the body only in-text citations (Author, Year); translate ALL section headers into the output language. See `assets/example-brief.md` for a real, complete example of the expected output.
6. **Verify and AUDIT (mandatory, do not skip)**:
   - a) Run `scripts/verify_dois.py research/brief-<topic>.md` — fix or remove any DOI marked as not verified.
   - b) Run `scripts/audit.py research/brief-<topic>.md` — it checks section order (References last), no placeholders, DOI link format, DOI uniqueness, and that every in-text citation has a References entry and vice versa. It must print `RESULT: PASS`.
   - c) **Semantic audit (you do this yourself)**: re-read every claim in "Summary and findings" and "Implications" and confirm it is supported by the cited source's abstract (no invented statistics, quotes, or findings); confirm in-text citations match the reference authors/years; confirm Implications avoid causal overclaiming ("associated with", not "causes", unless a source states causality); confirm the language is consistent throughout. Fix anything that fails and re-run audit.py until PASS.
7. **Deliver**: save the brief to `research/brief-<topic>.md`, write `research/search-log.md` (queries used per iteration, sources found per database, sources selected, audit result), and reply in chat with: an executive summary (3–5 lines), the source list with DOIs, the audit result, and the file paths.

## Golden rules

- NEVER invent sources, DOIs, citations, or page numbers.
- A source without a DOI is cited without one.
- If there are not enough relevant sources, say so explicitly instead of padding with generalities.
- No extra sections (no Introduction, Methods, Discussion, Conclusion).
- Never deliver a brief that has not passed `audit.py` with `RESULT: PASS`.
- Do not ask for API keys: the agent reasons by itself; the scripts only use optional env vars (`PUBMED_API_KEY`, `S2_API_KEY`, `CROSSREF_EMAIL`).

## When NOT to use this skill

- For general opinion without evidence, recent news, or non-academic tasks.
- For a full systematic review with PRISMA flow and risk-of-bias assessment (this skill produces a rapid, auditable brief, not a systematic review).
- Do not modify project code unless the user explicitly asks.
